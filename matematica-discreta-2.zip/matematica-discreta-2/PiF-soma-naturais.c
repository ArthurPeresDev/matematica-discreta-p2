//Digite um numero inteiro positivo: 5
//A soma de 1 ate 5 e 15

#include <stdio.h>

int main() {
    int n;
    int i;
    int soma = 0;

    printf("Digite um numero inteiro positivo: ");
    scanf("%d", &n);

    for(i = 1; i <= n; i++) {
        soma += i;
    }

    printf("A soma de 1 ate %d e %d\n", n, soma);

    return 0;
}
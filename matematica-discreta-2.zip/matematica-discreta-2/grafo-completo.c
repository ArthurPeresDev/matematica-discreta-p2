// Nesse exercício é uma funçãi para calcular o número de
// arestas  de um grafo completo.

#include <stdio.h>

int main() {
    int n;
    int arestas;

    printf("Digite a quantidade de vertices: ");
    scanf("%d", &n);

    arestas = (n * (n - 1)) / 2;

    printf("O grafo completo possui %d arestas.\n", arestas);

    return 0;
}
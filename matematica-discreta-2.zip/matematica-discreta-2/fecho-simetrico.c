//Se existe: (a, b)
//Deve existir (b, a)

#include <stdio.h>

int main() {
    int a;
    int b;

    printf("Digite o primeiro elemento: ");
    scanf("%d", &a);

    printf("Digite o segundo elemento: ");
    scanf("%d", &b);

    printf("\nRelacao original: (%d,%d)\n", a, b);
    printf("Par necessario para o fecho simetrico: (%d,%d)\n", b, a);

    return 0;
}
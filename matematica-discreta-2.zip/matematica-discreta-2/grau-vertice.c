// O grau de um vértice corresponde à quantidade 
// de arestas ligadas a ele.

#include <stdio.h>

int main() {
    int grau = 0;
    int quantidade;
    int i;

    printf("Quantas arestas chegam ao vertice? ");
    scanf("%d", &quantidade);

    for(i = 0; i < quantidade; i++) {
        grau++;
    }

    printf("O grau do vertice e %d\n", grau);

    return 0;
}
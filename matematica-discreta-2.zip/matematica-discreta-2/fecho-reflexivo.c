// Uma relação é reflexiva quando todo elemento se relaciona consigo mesmo.

#include <stdio.h>

int main() {
    int n;
    int i;

    printf("Quantidade de elementos do conjunto: ");
    scanf("%d", &n);

    printf("Fecho reflexivo:\n");

    for(i = 1; i <= n; i++) {
        printf("(%d,%d)\n", i, i);
    }

    return 0;
}